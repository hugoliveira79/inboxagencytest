<?php
	include('Class.user.php');

		/*
		OTHER CONTROLLER FUNCTIONS
	*/

?>