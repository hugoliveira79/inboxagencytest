<?php
	include('Class.purchase.php');
		/*
		OTHER CONTROLLER FUNCTIONS
	*/
?>