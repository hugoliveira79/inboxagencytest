<?php
	include('Class.shoppingcart.php');

	/*
		OTHER CONTROLLER FUNCTIONS
	*/
?>