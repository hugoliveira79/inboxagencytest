<nav>
	<ul>
		<li class="col-xs-6"><a href="index.php?area=list">Book List </li>
		<li class="col-xs-6" ><a href="logout.php">Logout</a></li>


	</ul>
</nav>