
<div class="col-xs-4 col-lg-offset-4 form">
	<fieldset>
		<form action="validate-login.php" method="post">
		<ul>
			<li><label>Login:</label><input type="text" name="login"></li>
			<li><label>Password:</label><input type="text" name="password"></li>
			<li><input type="submit" value="login"></li>
			
		</ul>
	</form>
	</fieldset>
	
</div>